﻿namespace ST_Project
{
    partial class Highscore
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.p9 = new System.Windows.Forms.Label();
            this.p8 = new System.Windows.Forms.Label();
            this.p7 = new System.Windows.Forms.Label();
            this.p6 = new System.Windows.Forms.Label();
            this.p5 = new System.Windows.Forms.Label();
            this.p4 = new System.Windows.Forms.Label();
            this.p3 = new System.Windows.Forms.Label();
            this.p2 = new System.Windows.Forms.Label();
            this.p1 = new System.Windows.Forms.Label();
            this.s9 = new System.Windows.Forms.Label();
            this.s8 = new System.Windows.Forms.Label();
            this.s7 = new System.Windows.Forms.Label();
            this.s6 = new System.Windows.Forms.Label();
            this.s5 = new System.Windows.Forms.Label();
            this.s4 = new System.Windows.Forms.Label();
            this.s3 = new System.Windows.Forms.Label();
            this.s2 = new System.Windows.Forms.Label();
            this.s1 = new System.Windows.Forms.Label();
            this.s10 = new System.Windows.Forms.Label();
            this.p10 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 22.125F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(450, 55);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(343, 67);
            this.label1.TabIndex = 0;
            this.label1.Text = "Highscores:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(254, 184);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(24, 25);
            this.label2.TabIndex = 1;
            this.label2.Text = "1";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(254, 209);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(24, 25);
            this.label3.TabIndex = 2;
            this.label3.Text = "2";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(254, 234);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(24, 25);
            this.label4.TabIndex = 3;
            this.label4.Text = "3";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(254, 259);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(24, 25);
            this.label5.TabIndex = 4;
            this.label5.Text = "4";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(254, 284);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(24, 25);
            this.label6.TabIndex = 5;
            this.label6.Text = "5";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(254, 309);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(24, 25);
            this.label7.TabIndex = 6;
            this.label7.Text = "6";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(254, 334);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(24, 25);
            this.label8.TabIndex = 7;
            this.label8.Text = "7";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(254, 359);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(24, 25);
            this.label9.TabIndex = 8;
            this.label9.Text = "8";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(254, 384);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(24, 25);
            this.label10.TabIndex = 9;
            this.label10.Text = "9";
            // 
            // p9
            // 
            this.p9.AutoSize = true;
            this.p9.Location = new System.Drawing.Point(396, 384);
            this.p9.Name = "p9";
            this.p9.Size = new System.Drawing.Size(82, 25);
            this.p9.TabIndex = 18;
            this.p9.Text = "label10";
            // 
            // p8
            // 
            this.p8.AutoSize = true;
            this.p8.Location = new System.Drawing.Point(396, 359);
            this.p8.Name = "p8";
            this.p8.Size = new System.Drawing.Size(82, 25);
            this.p8.TabIndex = 17;
            this.p8.Text = "label12";
            // 
            // p7
            // 
            this.p7.AutoSize = true;
            this.p7.Location = new System.Drawing.Point(396, 334);
            this.p7.Name = "p7";
            this.p7.Size = new System.Drawing.Size(82, 25);
            this.p7.TabIndex = 16;
            this.p7.Text = "label13";
            // 
            // p6
            // 
            this.p6.AutoSize = true;
            this.p6.Location = new System.Drawing.Point(396, 309);
            this.p6.Name = "p6";
            this.p6.Size = new System.Drawing.Size(82, 25);
            this.p6.TabIndex = 15;
            this.p6.Text = "label14";
            // 
            // p5
            // 
            this.p5.AutoSize = true;
            this.p5.Location = new System.Drawing.Point(396, 284);
            this.p5.Name = "p5";
            this.p5.Size = new System.Drawing.Size(82, 25);
            this.p5.TabIndex = 14;
            this.p5.Text = "label15";
            // 
            // p4
            // 
            this.p4.AutoSize = true;
            this.p4.Location = new System.Drawing.Point(396, 259);
            this.p4.Name = "p4";
            this.p4.Size = new System.Drawing.Size(82, 25);
            this.p4.TabIndex = 13;
            this.p4.Text = "label16";
            // 
            // p3
            // 
            this.p3.AutoSize = true;
            this.p3.Location = new System.Drawing.Point(396, 234);
            this.p3.Name = "p3";
            this.p3.Size = new System.Drawing.Size(82, 25);
            this.p3.TabIndex = 12;
            this.p3.Text = "label17";
            // 
            // p2
            // 
            this.p2.AutoSize = true;
            this.p2.Location = new System.Drawing.Point(396, 209);
            this.p2.Name = "p2";
            this.p2.Size = new System.Drawing.Size(82, 25);
            this.p2.TabIndex = 11;
            this.p2.Text = "label18";
            // 
            // p1
            // 
            this.p1.AutoSize = true;
            this.p1.Location = new System.Drawing.Point(396, 184);
            this.p1.Name = "p1";
            this.p1.Size = new System.Drawing.Size(82, 25);
            this.p1.TabIndex = 10;
            this.p1.Text = "label19";
            // 
            // s9
            // 
            this.s9.AutoSize = true;
            this.s9.Location = new System.Drawing.Point(725, 384);
            this.s9.Name = "s9";
            this.s9.Size = new System.Drawing.Size(70, 25);
            this.s9.TabIndex = 27;
            this.s9.Text = "label1";
            // 
            // s8
            // 
            this.s8.AutoSize = true;
            this.s8.Location = new System.Drawing.Point(725, 359);
            this.s8.Name = "s8";
            this.s8.Size = new System.Drawing.Size(82, 25);
            this.s8.TabIndex = 26;
            this.s8.Text = "label21";
            // 
            // s7
            // 
            this.s7.AutoSize = true;
            this.s7.Location = new System.Drawing.Point(725, 334);
            this.s7.Name = "s7";
            this.s7.Size = new System.Drawing.Size(82, 25);
            this.s7.TabIndex = 25;
            this.s7.Text = "label22";
            // 
            // s6
            // 
            this.s6.AutoSize = true;
            this.s6.Location = new System.Drawing.Point(725, 309);
            this.s6.Name = "s6";
            this.s6.Size = new System.Drawing.Size(82, 25);
            this.s6.TabIndex = 24;
            this.s6.Text = "label23";
            // 
            // s5
            // 
            this.s5.AutoSize = true;
            this.s5.Location = new System.Drawing.Point(725, 284);
            this.s5.Name = "s5";
            this.s5.Size = new System.Drawing.Size(82, 25);
            this.s5.TabIndex = 23;
            this.s5.Text = "label24";
            // 
            // s4
            // 
            this.s4.AutoSize = true;
            this.s4.Location = new System.Drawing.Point(725, 259);
            this.s4.Name = "s4";
            this.s4.Size = new System.Drawing.Size(82, 25);
            this.s4.TabIndex = 22;
            this.s4.Text = "label25";
            // 
            // s3
            // 
            this.s3.AutoSize = true;
            this.s3.Location = new System.Drawing.Point(725, 234);
            this.s3.Name = "s3";
            this.s3.Size = new System.Drawing.Size(82, 25);
            this.s3.TabIndex = 21;
            this.s3.Text = "label26";
            // 
            // s2
            // 
            this.s2.AutoSize = true;
            this.s2.Location = new System.Drawing.Point(725, 209);
            this.s2.Name = "s2";
            this.s2.Size = new System.Drawing.Size(82, 25);
            this.s2.TabIndex = 20;
            this.s2.Text = "label27";
            // 
            // s1
            // 
            this.s1.AutoSize = true;
            this.s1.Location = new System.Drawing.Point(725, 184);
            this.s1.Name = "s1";
            this.s1.Size = new System.Drawing.Size(82, 25);
            this.s1.TabIndex = 19;
            this.s1.Text = "label28";
            // 
            // s10
            // 
            this.s10.AutoSize = true;
            this.s10.Location = new System.Drawing.Point(725, 409);
            this.s10.Name = "s10";
            this.s10.Size = new System.Drawing.Size(70, 25);
            this.s10.TabIndex = 30;
            this.s10.Text = "label1";
            // 
            // p10
            // 
            this.p10.AutoSize = true;
            this.p10.Location = new System.Drawing.Point(396, 409);
            this.p10.Name = "p10";
            this.p10.Size = new System.Drawing.Size(82, 25);
            this.p10.TabIndex = 29;
            this.p10.Text = "label10";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(254, 409);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(36, 25);
            this.label31.TabIndex = 28;
            this.label31.Text = "10";
            // 
            // Highscore
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1254, 649);
            this.Controls.Add(this.s10);
            this.Controls.Add(this.p10);
            this.Controls.Add(this.label31);
            this.Controls.Add(this.s9);
            this.Controls.Add(this.s8);
            this.Controls.Add(this.s7);
            this.Controls.Add(this.s6);
            this.Controls.Add(this.s5);
            this.Controls.Add(this.s4);
            this.Controls.Add(this.s3);
            this.Controls.Add(this.s2);
            this.Controls.Add(this.s1);
            this.Controls.Add(this.p9);
            this.Controls.Add(this.p8);
            this.Controls.Add(this.p7);
            this.Controls.Add(this.p6);
            this.Controls.Add(this.p5);
            this.Controls.Add(this.p4);
            this.Controls.Add(this.p3);
            this.Controls.Add(this.p2);
            this.Controls.Add(this.p1);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Highscore";
            this.Text = "Highscore";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label p9;
        private System.Windows.Forms.Label p8;
        private System.Windows.Forms.Label p7;
        private System.Windows.Forms.Label p6;
        private System.Windows.Forms.Label p5;
        private System.Windows.Forms.Label p4;
        private System.Windows.Forms.Label p3;
        private System.Windows.Forms.Label p2;
        private System.Windows.Forms.Label p1;
        private System.Windows.Forms.Label s9;
        private System.Windows.Forms.Label s8;
        private System.Windows.Forms.Label s7;
        private System.Windows.Forms.Label s6;
        private System.Windows.Forms.Label s5;
        private System.Windows.Forms.Label s4;
        private System.Windows.Forms.Label s3;
        private System.Windows.Forms.Label s2;
        private System.Windows.Forms.Label s1;
        private System.Windows.Forms.Label s10;
        private System.Windows.Forms.Label p10;
        private System.Windows.Forms.Label label31;
    }
}