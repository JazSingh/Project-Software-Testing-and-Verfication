﻿namespace ST_Project
{
    partial class Gamescherm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.potions_lbl = new System.Windows.Forms.Label();
            this.scrolls_lbl = new System.Windows.Forms.Label();
            this.crystal_lbl = new System.Windows.Forms.Label();
            this.NRpotions = new System.Windows.Forms.Label();
            this.NRcrystals = new System.Windows.Forms.Label();
            this.NRscrolls = new System.Windows.Forms.Label();
            this.Health_lbl = new System.Windows.Forms.Label();
            this.NRhealth = new System.Windows.Forms.Label();
            this.fight_button = new System.Windows.Forms.Button();
            this.use_pot = new System.Windows.Forms.Button();
            this.use_crystal = new System.Windows.Forms.Button();
            this.use_scroll = new System.Windows.Forms.Button();
            this.score_lbl = new System.Windows.Forms.Label();
            this.NRScore = new System.Windows.Forms.Label();
            this.level_lbl = new System.Windows.Forms.Label();
            this.NRLevel = new System.Windows.Forms.Label();
            this.pack1 = new System.Windows.Forms.Label();
            this.pack_hp = new System.Windows.Forms.Label();
            this.pack_monsters = new System.Windows.Forms.Label();
            this.pack_item = new System.Windows.Forms.Label();
            this.p_hp = new System.Windows.Forms.Label();
            this.p_monsters = new System.Windows.Forms.Label();
            this.p_item = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.total_packs = new System.Windows.Forms.Label();
            this.packs_node = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.cur_item = new System.Windows.Forms.Label();
            this.itdur = new System.Windows.Forms.Label();
            this.current_item = new System.Windows.Forms.Label();
            this.item_duration = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // potions_lbl
            // 
            this.potions_lbl.AutoSize = true;
            this.potions_lbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.potions_lbl.Location = new System.Drawing.Point(118, 513);
            this.potions_lbl.Name = "potions_lbl";
            this.potions_lbl.Size = new System.Drawing.Size(145, 24);
            this.potions_lbl.TabIndex = 0;
            this.potions_lbl.Text = "Health Potions";
            // 
            // scrolls_lbl
            // 
            this.scrolls_lbl.AutoSize = true;
            this.scrolls_lbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.scrolls_lbl.Location = new System.Drawing.Point(495, 513);
            this.scrolls_lbl.Name = "scrolls_lbl";
            this.scrolls_lbl.Size = new System.Drawing.Size(135, 24);
            this.scrolls_lbl.TabIndex = 1;
            this.scrolls_lbl.Text = "Magic Scrolls";
            // 
            // crystal_lbl
            // 
            this.crystal_lbl.AutoSize = true;
            this.crystal_lbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.crystal_lbl.Location = new System.Drawing.Point(309, 513);
            this.crystal_lbl.Name = "crystal_lbl";
            this.crystal_lbl.Size = new System.Drawing.Size(135, 24);
            this.crystal_lbl.TabIndex = 2;
            this.crystal_lbl.Text = "Time Crystals";
            // 
            // NRpotions
            // 
            this.NRpotions.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NRpotions.Location = new System.Drawing.Point(118, 556);
            this.NRpotions.Name = "NRpotions";
            this.NRpotions.Size = new System.Drawing.Size(152, 22);
            this.NRpotions.TabIndex = 3;
            this.NRpotions.Text = "0";
            this.NRpotions.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // NRcrystals
            // 
            this.NRcrystals.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NRcrystals.Location = new System.Drawing.Point(309, 556);
            this.NRcrystals.Name = "NRcrystals";
            this.NRcrystals.Size = new System.Drawing.Size(152, 22);
            this.NRcrystals.TabIndex = 4;
            this.NRcrystals.Text = "0";
            this.NRcrystals.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // NRscrolls
            // 
            this.NRscrolls.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NRscrolls.Location = new System.Drawing.Point(495, 556);
            this.NRscrolls.Name = "NRscrolls";
            this.NRscrolls.Size = new System.Drawing.Size(152, 22);
            this.NRscrolls.TabIndex = 5;
            this.NRscrolls.Text = "0";
            this.NRscrolls.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Health_lbl
            // 
            this.Health_lbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Health_lbl.Location = new System.Drawing.Point(116, 420);
            this.Health_lbl.Name = "Health_lbl";
            this.Health_lbl.Size = new System.Drawing.Size(76, 33);
            this.Health_lbl.TabIndex = 6;
            this.Health_lbl.Text = "HP:";
            // 
            // NRhealth
            // 
            this.NRhealth.AutoSize = true;
            this.NRhealth.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NRhealth.Location = new System.Drawing.Point(231, 420);
            this.NRhealth.Name = "NRhealth";
            this.NRhealth.Size = new System.Drawing.Size(32, 33);
            this.NRhealth.TabIndex = 7;
            this.NRhealth.Text = "0";
            // 
            // fight_button
            // 
            this.fight_button.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fight_button.Location = new System.Drawing.Point(636, 450);
            this.fight_button.Name = "fight_button";
            this.fight_button.Size = new System.Drawing.Size(196, 128);
            this.fight_button.TabIndex = 8;
            this.fight_button.Text = "Fight!";
            this.fight_button.UseVisualStyleBackColor = true;
            this.fight_button.Visible = false;
            this.fight_button.Click += new System.EventHandler(this.fight_button_Click);
            // 
            // use_pot
            // 
            this.use_pot.Location = new System.Drawing.Point(156, 603);
            this.use_pot.Name = "use_pot";
            this.use_pot.Size = new System.Drawing.Size(75, 23);
            this.use_pot.TabIndex = 9;
            this.use_pot.Text = "Use Potion";
            this.use_pot.UseVisualStyleBackColor = true;
            this.use_pot.Click += new System.EventHandler(this.use_pot_Click);
            // 
            // use_crystal
            // 
            this.use_crystal.Location = new System.Drawing.Point(325, 603);
            this.use_crystal.Name = "use_crystal";
            this.use_crystal.Size = new System.Drawing.Size(110, 23);
            this.use_crystal.TabIndex = 10;
            this.use_crystal.Text = "Use Time Crystal";
            this.use_crystal.UseVisualStyleBackColor = true;
            this.use_crystal.Click += new System.EventHandler(this.use_crystal_Click);
            // 
            // use_scroll
            // 
            this.use_scroll.Location = new System.Drawing.Point(521, 603);
            this.use_scroll.Name = "use_scroll";
            this.use_scroll.Size = new System.Drawing.Size(97, 23);
            this.use_scroll.TabIndex = 11;
            this.use_scroll.Text = "Use Magic Scroll";
            this.use_scroll.UseVisualStyleBackColor = true;
            this.use_scroll.Click += new System.EventHandler(this.use_scroll_Click);
            // 
            // score_lbl
            // 
            this.score_lbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.score_lbl.Location = new System.Drawing.Point(374, 420);
            this.score_lbl.Name = "score_lbl";
            this.score_lbl.Size = new System.Drawing.Size(114, 33);
            this.score_lbl.TabIndex = 12;
            this.score_lbl.Text = "Score:";
            // 
            // NRScore
            // 
            this.NRScore.AutoSize = true;
            this.NRScore.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NRScore.Location = new System.Drawing.Point(515, 420);
            this.NRScore.Name = "NRScore";
            this.NRScore.Size = new System.Drawing.Size(32, 33);
            this.NRScore.TabIndex = 13;
            this.NRScore.Text = "0";
            // 
            // level_lbl
            // 
            this.level_lbl.AutoSize = true;
            this.level_lbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.level_lbl.Location = new System.Drawing.Point(548, 28);
            this.level_lbl.Name = "level_lbl";
            this.level_lbl.Size = new System.Drawing.Size(99, 33);
            this.level_lbl.TabIndex = 14;
            this.level_lbl.Text = "Level:";
            // 
            // NRLevel
            // 
            this.NRLevel.AutoSize = true;
            this.NRLevel.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NRLevel.Location = new System.Drawing.Point(653, 28);
            this.NRLevel.Name = "NRLevel";
            this.NRLevel.Size = new System.Drawing.Size(32, 33);
            this.NRLevel.TabIndex = 15;
            this.NRLevel.Text = "0";
            // 
            // pack1
            // 
            this.pack1.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pack1.Location = new System.Drawing.Point(902, 386);
            this.pack1.Name = "pack1";
            this.pack1.Size = new System.Drawing.Size(218, 33);
            this.pack1.TabIndex = 16;
            this.pack1.Text = "Current Pack";
            this.pack1.Visible = false;
            // 
            // pack_hp
            // 
            this.pack_hp.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pack_hp.Location = new System.Drawing.Point(838, 472);
            this.pack_hp.Name = "pack_hp";
            this.pack_hp.Size = new System.Drawing.Size(67, 33);
            this.pack_hp.TabIndex = 17;
            this.pack_hp.Text = "HP:";
            this.pack_hp.Visible = false;
            // 
            // pack_monsters
            // 
            this.pack_monsters.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pack_monsters.Location = new System.Drawing.Point(838, 505);
            this.pack_monsters.Name = "pack_monsters";
            this.pack_monsters.Size = new System.Drawing.Size(182, 33);
            this.pack_monsters.TabIndex = 18;
            this.pack_monsters.Text = "# Monsters:";
            this.pack_monsters.Visible = false;
            // 
            // pack_item
            // 
            this.pack_item.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pack_item.Location = new System.Drawing.Point(838, 547);
            this.pack_item.Name = "pack_item";
            this.pack_item.Size = new System.Drawing.Size(182, 33);
            this.pack_item.TabIndex = 19;
            this.pack_item.Text = "Drops Item:";
            this.pack_item.Visible = false;
            // 
            // p_hp
            // 
            this.p_hp.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.p_hp.Location = new System.Drawing.Point(1021, 463);
            this.p_hp.Name = "p_hp";
            this.p_hp.Size = new System.Drawing.Size(231, 33);
            this.p_hp.TabIndex = 20;
            this.p_hp.Text = "num";
            this.p_hp.Visible = false;
            // 
            // p_monsters
            // 
            this.p_monsters.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.p_monsters.Location = new System.Drawing.Point(1026, 505);
            this.p_monsters.Name = "p_monsters";
            this.p_monsters.Size = new System.Drawing.Size(226, 33);
            this.p_monsters.TabIndex = 21;
            this.p_monsters.Text = "num";
            this.p_monsters.Visible = false;
            // 
            // p_item
            // 
            this.p_item.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.p_item.Location = new System.Drawing.Point(1021, 547);
            this.p_item.Name = "p_item";
            this.p_item.Size = new System.Drawing.Size(231, 33);
            this.p_item.TabIndex = 23;
            this.p_item.Text = "item";
            this.p_item.Visible = false;
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, 324);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(195, 33);
            this.label1.TabIndex = 24;
            this.label1.Text = "Total Packs:";
            // 
            // total_packs
            // 
            this.total_packs.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.total_packs.Location = new System.Drawing.Point(213, 324);
            this.total_packs.Name = "total_packs";
            this.total_packs.Size = new System.Drawing.Size(76, 33);
            this.total_packs.TabIndex = 25;
            this.total_packs.Text = "0";
            // 
            // packs_node
            // 
            this.packs_node.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.packs_node.Location = new System.Drawing.Point(287, 368);
            this.packs_node.Name = "packs_node";
            this.packs_node.Size = new System.Drawing.Size(76, 33);
            this.packs_node.TabIndex = 27;
            this.packs_node.Text = "0";
            // 
            // label3
            // 
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(12, 368);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(287, 33);
            this.label3.TabIndex = 26;
            this.label3.Text = "Packs in this node:";
            // 
            // cur_item
            // 
            this.cur_item.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cur_item.Location = new System.Drawing.Point(391, 324);
            this.cur_item.Name = "cur_item";
            this.cur_item.Size = new System.Drawing.Size(204, 33);
            this.cur_item.TabIndex = 28;
            this.cur_item.Text = "Current Item:";
            // 
            // itdur
            // 
            this.itdur.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.itdur.Location = new System.Drawing.Point(391, 368);
            this.itdur.Name = "itdur";
            this.itdur.Size = new System.Drawing.Size(145, 33);
            this.itdur.TabIndex = 29;
            this.itdur.Text = "Duration:";
            // 
            // current_item
            // 
            this.current_item.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.current_item.Location = new System.Drawing.Point(594, 324);
            this.current_item.Name = "current_item";
            this.current_item.Size = new System.Drawing.Size(204, 33);
            this.current_item.TabIndex = 30;
            this.current_item.Text = "None";
            // 
            // item_duration
            // 
            this.item_duration.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.item_duration.Location = new System.Drawing.Point(531, 368);
            this.item_duration.Name = "item_duration";
            this.item_duration.Size = new System.Drawing.Size(76, 33);
            this.item_duration.TabIndex = 31;
            this.item_duration.Text = "0";
            // 
            // Gamescherm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1264, 681);
            this.Controls.Add(this.item_duration);
            this.Controls.Add(this.current_item);
            this.Controls.Add(this.itdur);
            this.Controls.Add(this.cur_item);
            this.Controls.Add(this.packs_node);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.total_packs);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.p_item);
            this.Controls.Add(this.p_monsters);
            this.Controls.Add(this.p_hp);
            this.Controls.Add(this.pack_item);
            this.Controls.Add(this.pack_monsters);
            this.Controls.Add(this.pack_hp);
            this.Controls.Add(this.pack1);
            this.Controls.Add(this.NRLevel);
            this.Controls.Add(this.level_lbl);
            this.Controls.Add(this.NRScore);
            this.Controls.Add(this.score_lbl);
            this.Controls.Add(this.use_scroll);
            this.Controls.Add(this.use_crystal);
            this.Controls.Add(this.use_pot);
            this.Controls.Add(this.fight_button);
            this.Controls.Add(this.NRhealth);
            this.Controls.Add(this.Health_lbl);
            this.Controls.Add(this.NRscrolls);
            this.Controls.Add(this.NRcrystals);
            this.Controls.Add(this.NRpotions);
            this.Controls.Add(this.crystal_lbl);
            this.Controls.Add(this.scrolls_lbl);
            this.Controls.Add(this.potions_lbl);
            this.DoubleBuffered = true;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "Gamescherm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Gamescherm";
            this.Load += new System.EventHandler(this.Gamescherm_Load);
            this.MouseClick += new System.Windows.Forms.MouseEventHandler(this.CheckMove);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label potions_lbl;
        private System.Windows.Forms.Label scrolls_lbl;
        private System.Windows.Forms.Label crystal_lbl;
        private System.Windows.Forms.Label NRpotions;
        private System.Windows.Forms.Label NRcrystals;
        private System.Windows.Forms.Label NRscrolls;
        private System.Windows.Forms.Label Health_lbl;
        private System.Windows.Forms.Label NRhealth;
        private System.Windows.Forms.Button fight_button;
        private System.Windows.Forms.Button use_pot;
        private System.Windows.Forms.Button use_crystal;
        private System.Windows.Forms.Button use_scroll;
        private System.Windows.Forms.Label score_lbl;
        private System.Windows.Forms.Label NRScore;
        private System.Windows.Forms.Label level_lbl;
        private System.Windows.Forms.Label NRLevel;
        private System.Windows.Forms.Label pack1;
        private System.Windows.Forms.Label pack_hp;
        private System.Windows.Forms.Label pack_monsters;
        private System.Windows.Forms.Label pack_item;
        private System.Windows.Forms.Label p_hp;
        private System.Windows.Forms.Label p_monsters;
        private System.Windows.Forms.Label p_item;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label total_packs;
        private System.Windows.Forms.Label packs_node;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label cur_item;
        private System.Windows.Forms.Label itdur;
        private System.Windows.Forms.Label current_item;
        private System.Windows.Forms.Label item_duration;

    }
}