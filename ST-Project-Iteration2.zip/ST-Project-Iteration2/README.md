# ST-Project - Iteration 2

Project by:
- Daniël Stekelenburg, 4153286
- Daan Jacobs, 4123581
- Jaspreet Singh, 3754022

To build the project: clone the solution and open the the solution file in Visual Studio.

The project and test project are situated in the same solution.

The executables have been tested on 64-bit machines exclusively.

An URL to download the executables: -- 

Download and unzip the file. Run the ST-Project.exe file to play.
